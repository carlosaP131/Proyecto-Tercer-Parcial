/** ***************************************************************************
 * @author Carlos Aurelio Alcántara Pérez
 *Fecha de creación: 07-04-2022
 ***
 * @version Fecha de actualización:22-06-2022
 * @deprecated Ventana juego 
 * *************************************************************************
 */
package ahorcado.juego.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;

public class Juego extends javax.swing.JFrame {
//declarqacion de variables 

    BasicPlayer sonido = new BasicPlayer();
    BasicPlayer player = new BasicPlayer();

    private int pausado;//para el boton de pausa
    private String aciertos; // mostrataciertos
    private String errores;//mostrar errores
    private int indice = 0;//indice para contar palabras 

    private int intentospositivos = 0;// errores
    private int intentosnegativos = 0;//aciertos

    private String palabra;
    private final String palabras[] = {
        "ECLIPSE", "PALABRA", "JUGAR",
        "OBJETO", "CLASES", "METODO"};//lista de palabras
    private ArrayList<Integer> coincidencias;
    private ArrayList<JLabel> letras;

    /**
     * constructor para implementacion del juego
     */
    public Juego() {

        this.palabra = palabraRandom();
        this.coincidencias = new ArrayList<>();

        initComponents();
        vaciarletras();
        inciarmonito();
        this.setLocationRelativeTo(null);
        ERROR.setText(" ");
        ACIERTOS.setText("  ");

    }
/**
 * 
 * @param audio constructor para no perder el control del audio 
 */
    public Juego(BasicPlayer audio) {
        this.palabra = palabraRandom();
        this.coincidencias = new ArrayList<>();
        this.player = audio;

        initComponents();
        vaciarletras();
        inciarmonito();
        this.setLocationRelativeTo(null);
         ERROR.setText(" ");
        ACIERTOS.setText("  ");

    }

   

   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        a = new javax.swing.JButton();
        b = new javax.swing.JButton();
        c = new javax.swing.JButton();
        d = new javax.swing.JButton();
        e = new javax.swing.JButton();
        f = new javax.swing.JButton();
        g = new javax.swing.JButton();
        h = new javax.swing.JButton();
        i = new javax.swing.JButton();
        j = new javax.swing.JButton();
        k = new javax.swing.JButton();
        t = new javax.swing.JButton();
        s = new javax.swing.JButton();
        r = new javax.swing.JButton();
        q = new javax.swing.JButton();
        p = new javax.swing.JButton();
        o = new javax.swing.JButton();
        ñ = new javax.swing.JButton();
        m = new javax.swing.JButton();
        n = new javax.swing.JButton();
        l = new javax.swing.JButton();
        u = new javax.swing.JButton();
        v = new javax.swing.JButton();
        w = new javax.swing.JButton();
        x = new javax.swing.JButton();
        Y = new javax.swing.JButton();
        z = new javax.swing.JButton();
        silencio = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        LACIERTOS = new javax.swing.JLabel();
        LERROR = new javax.swing.JLabel();
        ACIERTOS = new javax.swing.JTextField();
        ERROR = new javax.swing.JTextField();
        monito = new javax.swing.JLabel();
        Atras = new javax.swing.JButton();
        PALABRAS = new javax.swing.JPanel();
        fondo = new javax.swing.JLabel();
        Respuesta8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(906, 508));

        jPanel1.setBackground(new java.awt.Color(159, 197, 248));
        jPanel1.setMinimumSize(new java.awt.Dimension(900, 508));
        jPanel1.setPreferredSize(new java.awt.Dimension(900, 508));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        a.setText("A");
        a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aActionPerformed(evt);
            }
        });
        jPanel1.add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 330, -1, -1));

        b.setText("B");
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });
        jPanel1.add(b, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 330, -1, -1));

        c.setText("C");
        c.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cActionPerformed(evt);
            }
        });
        jPanel1.add(c, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, -1, -1));

        d.setText("D");
        d.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dActionPerformed(evt);
            }
        });
        jPanel1.add(d, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 330, -1, -1));

        e.setText("E");
        e.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eActionPerformed(evt);
            }
        });
        jPanel1.add(e, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 330, -1, -1));

        f.setText("F");
        f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fActionPerformed(evt);
            }
        });
        jPanel1.add(f, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, -1, -1));

        g.setText("G");
        g.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gActionPerformed(evt);
            }
        });
        jPanel1.add(g, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 330, -1, -1));

        h.setText("H");
        h.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hActionPerformed(evt);
            }
        });
        jPanel1.add(h, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 330, -1, -1));

        i.setText("I");
        i.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iActionPerformed(evt);
            }
        });
        jPanel1.add(i, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 330, -1, -1));

        j.setText("J");
        j.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jActionPerformed(evt);
            }
        });
        jPanel1.add(j, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 330, -1, -1));

        k.setText("K");
        k.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kActionPerformed(evt);
            }
        });
        jPanel1.add(k, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 330, -1, -1));

        t.setText("T");
        t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tActionPerformed(evt);
            }
        });
        jPanel1.add(t, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 370, -1, -1));

        s.setText("S");
        s.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sActionPerformed(evt);
            }
        });
        jPanel1.add(s, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 370, -1, -1));

        r.setText("R");
        r.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rActionPerformed(evt);
            }
        });
        jPanel1.add(r, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 370, -1, -1));

        q.setText("Q");
        q.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qActionPerformed(evt);
            }
        });
        jPanel1.add(q, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 370, -1, -1));

        p.setText("P");
        p.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pActionPerformed(evt);
            }
        });
        jPanel1.add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 370, -1, -1));

        o.setText("O");
        o.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oActionPerformed(evt);
            }
        });
        jPanel1.add(o, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 370, -1, -1));

        ñ.setText("Ñ");
        ñ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ñActionPerformed(evt);
            }
        });
        jPanel1.add(ñ, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 370, -1, -1));

        m.setText("M");
        m.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mActionPerformed(evt);
            }
        });
        jPanel1.add(m, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 370, -1, -1));

        n.setText("N");
        n.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nActionPerformed(evt);
            }
        });
        jPanel1.add(n, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 370, -1, -1));

        l.setText("L");
        l.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lActionPerformed(evt);
            }
        });
        jPanel1.add(l, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 370, -1, -1));

        u.setText("U");
        u.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uActionPerformed(evt);
            }
        });
        jPanel1.add(u, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 410, -1, -1));

        v.setText("V");
        v.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vActionPerformed(evt);
            }
        });
        jPanel1.add(v, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 410, -1, -1));

        w.setText("W");
        w.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wActionPerformed(evt);
            }
        });
        jPanel1.add(w, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 410, -1, -1));

        x.setText("X");
        x.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                xActionPerformed(evt);
            }
        });
        jPanel1.add(x, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 410, -1, -1));

        Y.setText("Y");
        Y.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YActionPerformed(evt);
            }
        });
        jPanel1.add(Y, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 410, -1, -1));

        z.setText("Z");
        z.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zActionPerformed(evt);
            }
        });
        jPanel1.add(z, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 410, -1, -1));

        silencio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/SILENCIAR.png"))); // NOI18N
        silencio.setBorder(null);
        silencio.setBorderPainted(false);
        silencio.setContentAreaFilled(false);
        silencio.setDefaultCapable(false);
        silencio.setFocusPainted(false);
        silencio.setFocusable(false);
        silencio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                silencioActionPerformed(evt);
            }
        });
        jPanel1.add(silencio, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 470, -1, -1));

        reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/RESETEAR.png"))); // NOI18N
        reset.setBorder(null);
        reset.setBorderPainted(false);
        reset.setContentAreaFilled(false);
        reset.setFocusPainted(false);
        reset.setFocusable(false);
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jPanel1.add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 470, 110, -1));

        LACIERTOS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/ACIERTOS.png"))); // NOI18N
        jPanel1.add(LACIERTOS, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, -1, -1));

        LERROR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/ERRORES.png"))); // NOI18N
        jPanel1.add(LERROR, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 70, -1));

        ACIERTOS.setBackground(new java.awt.Color(82, 106, 84));
        ACIERTOS.setForeground(new java.awt.Color(255, 255, 255));
        ACIERTOS.setBorder(null);
        jPanel1.add(ACIERTOS, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 280, 70, 30));

        ERROR.setBackground(new java.awt.Color(82, 106, 84));
        ERROR.setForeground(new java.awt.Color(255, 255, 255));
        ERROR.setBorder(null);
        jPanel1.add(ERROR, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 70, 30));

        monito.setFont(new java.awt.Font("Liberation Sans", 0, 24)); // NOI18N
        jPanel1.add(monito, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 10, 260, 320));

        Atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/ATRAS.png"))); // NOI18N
        Atras.setBorderPainted(false);
        Atras.setContentAreaFilled(false);
        Atras.setDefaultCapable(false);
        Atras.setFocusPainted(false);
        Atras.setFocusable(false);
        Atras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtrasActionPerformed(evt);
            }
        });
        jPanel1.add(Atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 10, 110, -1));

        PALABRAS.setFocusable(false);
        PALABRAS.setFont(new java.awt.Font("Liberation Sans", 0, 24)); // NOI18N
        PALABRAS.setOpaque(false);

        javax.swing.GroupLayout PALABRASLayout = new javax.swing.GroupLayout(PALABRAS);
        PALABRAS.setLayout(PALABRASLayout);
        PALABRASLayout.setHorizontalGroup(
            PALABRASLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 580, Short.MAX_VALUE)
        );
        PALABRASLayout.setVerticalGroup(
            PALABRASLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        jPanel1.add(PALABRAS, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 580, 60));

        fondo.setForeground(new java.awt.Color(255, 255, 255));
        fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/FONDO.jpg"))); // NOI18N
        fondo.setMinimumSize(new java.awt.Dimension(953, 510));
        fondo.setOpaque(true);
        jPanel1.add(fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 510));

        Respuesta8.setFont(new java.awt.Font("Liberation Sans", 0, 24)); // NOI18N
        Respuesta8.setForeground(new java.awt.Color(255, 255, 255));
        Respuesta8.setText("O");
        jPanel1.add(Respuesta8, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 60, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
/**
 * 
 * @return  regresa una palabra aleatoria 
 * 
 */
    private String palabraRandom() {

        return palabras[(int) ((Math.random()) * (palabras.length))];
    }   
    /**
     * resetea el monito cada que se inicia el juego o se gana 
     */
    private void inciarmonito() {
        ImageIcon imagen= new ImageIcon(getClass().getResource
        ("/Media/Imagenes/ahorcado_0.png"));
        monito.setIcon(imagen);
    }
/**
 * 
 * @param letra
 * @return regresa si el boton correspode a la una letra dentro de la palabra  
 */
    private boolean esCorrecto(char letra) {

        for (int i = 0; i < palabra.length(); i++) {
            if (palabra.charAt(i) == letra) {
                return true;
            }
        }

        return false;
    }
/**
 * 
 * @param letra 
 * @param coincidencias 
 */
    private void coincidencias(char letra, ArrayList<Integer> coincidencias) {

        for (int i = 0; i < palabra.length(); i++) {
            if (palabra.charAt(i) == letra) {
                coincidencias.add(i);
            }
        }

    }
/**
 * 
 * @param lista
 * @param coincidenciaLetras 
 */
    private void mostrarCorrectas(ArrayList<JLabel> lista, ArrayList<Integer>
            coincidenciaLetras) {

        for (int i = 0; i < coincidenciaLetras.size(); i++) {

            lista.get(coincidenciaLetras.get(i)).setVisible(true);

        }

    }
/**
 * 
 * @param evt boton A 
 */
    private void aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aActionPerformed

        if (esCorrecto('A')) {
            coincidencias('A', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            a.setEnabled(false);

            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }


    }//GEN-LAST:event_aActionPerformed
/**
 * 
 * @param evt boton B
 */
    private void bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActionPerformed

        if (esCorrecto('B')) {
            coincidencias('B', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            b.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }


    }//GEN-LAST:event_bActionPerformed
/**
 * 
 * @param evt boton C
 */
    private void cActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cActionPerformed

        if (esCorrecto('C')) {
            coincidencias('C', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            c.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }


    }//GEN-LAST:event_cActionPerformed
/**
 * 
 * @param evt boton D
 */
    private void dActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dActionPerformed

        if (esCorrecto('D')) {
            coincidencias('D', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            d.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }

    }//GEN-LAST:event_dActionPerformed
/**
 * 
 * @param evt boton E
 */
    private void eActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eActionPerformed

        if (esCorrecto('E')) {
            coincidencias('E', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            e.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_eActionPerformed
/**
 * 
 * @param evt boton F
 * 
 */
    private void fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fActionPerformed

        if (esCorrecto('F')) {
            coincidencias('F', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            e.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_fActionPerformed
/**
 * 
 * @param evt boton REINICIAR
 */
    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        new Juego().setVisible(true);
        this.setVisible(false);
        vaciarletras();
        ACIERTOS.setText("");
        ERROR.setText("");
        reanudar();
        inciarmonito();
    }//GEN-LAST:event_resetActionPerformed
/**
 * 
 * @param evt boton Silenciar 
 */
    private void silencioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_silencioActionPerformed

        new PrincipalGrafico().mute();

    }//GEN-LAST:event_silencioActionPerformed

/**
 * 
 * @param evt boton para regresar ala pantalla principal 
 */
    private void AtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtrasActionPerformed
        new PrincipalGrafico(player).setVisible(true);
        this.hide();
    }//GEN-LAST:event_AtrasActionPerformed
/**
 * 
 * @param evt boton G
 */
    private void gActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gActionPerformed

        if (esCorrecto('G')) {
            coincidencias('G', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            h.setEnabled(false);
            if (intentospositivos == 6) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }

    }//GEN-LAST:event_gActionPerformed

    /**
     * 
     * @param evt boton H
     */
    private void hActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hActionPerformed

        if (esCorrecto('H')) {
            coincidencias('H', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            h.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "encontraste una letra");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }

    }//GEN-LAST:event_hActionPerformed
/**
 * 
 * @param evt  boton I
 */
    private void iActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iActionPerformed

        if (esCorrecto('I')) {
            coincidencias('I', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            i.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_iActionPerformed
/**
 * 
 * @param evt  boton J
 */
    private void jActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActionPerformed

        if (esCorrecto('J')) {
            coincidencias('J', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            j.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_jActionPerformed
/**
 * 
 * @param evt boton K
 */
    private void kActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kActionPerformed

        if (esCorrecto('K')) {
            coincidencias('K', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            k.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_kActionPerformed
/**
 * 
 * @param evt boton L
 */
    private void lActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lActionPerformed

        if (esCorrecto('L')) {
            coincidencias('L', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            l.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_lActionPerformed
/**
 * 
 * @param evt boton M
 */
    private void mActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mActionPerformed

        if (esCorrecto('M')) {
            coincidencias('M', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            m.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_mActionPerformed
/**
 * 
 * @param evt boton Ñ
 */
    private void ñActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ñActionPerformed

        if (esCorrecto('Ñ')) {
            coincidencias('Ñ', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            ñ.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_ñActionPerformed
/**
 * 
 * @param evt boton O
 */
    private void oActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oActionPerformed

        if (esCorrecto('O')) {
            coincidencias('O', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            o.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }

    }//GEN-LAST:event_oActionPerformed
/**
 * 
 * @param evt boton p
 */
    private void pActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pActionPerformed

        if (esCorrecto('P')) {
            coincidencias('P', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            p.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_pActionPerformed
/**
 * 
 * @param evt boton Q
 */
    private void qActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qActionPerformed

        if (esCorrecto('Q')) {
            coincidencias('Q', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;

            q.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_qActionPerformed
/**
 * 
 * @param evt boton R
 */
    private void rActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rActionPerformed

        if (esCorrecto('R')) {
            coincidencias('R', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            r.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }

    }//GEN-LAST:event_rActionPerformed
/**
 * 
 * @param evt boton S
 */
    private void sActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sActionPerformed

        if (esCorrecto('S')) {
            coincidencias('S', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            s.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");

                ACIERTOS.setText(aciertos.valueOf(intentospositivos));

            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_sActionPerformed
/**
 * 
 * @param evt boton T
 */
    private void tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tActionPerformed

        if (esCorrecto('T')) {
            coincidencias('T', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            t.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_tActionPerformed
/**
 * 
 * @param evt boton U
 */
    private void uActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uActionPerformed

        if (esCorrecto('U')) {
            coincidencias('U', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            u.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_uActionPerformed
/**
 * 
 * @param evt boton V 
 */
    private void vActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vActionPerformed

        if (esCorrecto('V')) {
            coincidencias('V', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            v.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_vActionPerformed
/**
 * 
 * @param evt boton W
 */
    private void wActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wActionPerformed

        if (esCorrecto('W')) {
            coincidencias('W', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            w.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_wActionPerformed
/**
 * 
 * @param evt boton X 
 */
    private void xActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_xActionPerformed

        if (esCorrecto('X')) {
            coincidencias('X', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            x.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_xActionPerformed
/** 
 * 
 * @param evt boton Y
 */
    private void YActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YActionPerformed

        if (esCorrecto('Y')) {
            coincidencias('Y', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            Y.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "ENCONTRASTE UNA LETRA");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));
            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");
            }
        }
    }//GEN-LAST:event_YActionPerformed
/**
 * 
 * @param evt boton Z
 */
    private void zActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zActionPerformed

        if (esCorrecto('Z')) {
            coincidencias('Z', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            z.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                inciarmonito();
            } else {
                JOptionPane.showMessageDialog(null, "encontraste una letra");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));

            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");

            }
        }
    }//GEN-LAST:event_zActionPerformed
/**
 * 
 * @param evt boton N 
 */
    private void nActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nActionPerformed

        if (esCorrecto('N')) {
            coincidencias('N', this.coincidencias);
            mostrarCorrectas(letras, coincidencias);
            intentospositivos = intentospositivos + 1;
            n.setEnabled(false);
            if (intentospositivos == 5) {
                JOptionPane.showMessageDialog(null, "!GANASTE¡");
                ImageIcon icon = new ImageIcon(getClass().getResource
        ("ahorcado_0.png"));
                monito.setIcon(icon);
            } else {
                JOptionPane.showMessageDialog(null, "encontraste una letra");
                ACIERTOS.setText(aciertos.valueOf(intentospositivos));
            }
        } else {
            indice++;
            imprimirmonito(indice);
            JOptionPane.showMessageDialog(null, "CASI ACIERTAS");
            intentosnegativos++;
            ERROR.setText(errores.valueOf(intentosnegativos));

            if (intentosnegativos == 6) {
                JOptionPane.showMessageDialog(null, "PERDISTE");

            }
        }
    }//GEN-LAST:event_nActionPerformed
/**
 * Método mute 
 */
    public void mute() {
        if (player.getStatus() == BasicPlayer.PAUSED) {

            try {
                player.resume();
            } catch (BasicPlayerException ex) {
                Logger.getLogger(PrincipalGrafico.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            try {
                player.pause();
            } catch (BasicPlayerException evt) {
            }

        }
    }

    /**
     * @param args main 
     */
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Juego().setVisible(true);
            }
        });
    }
/**
 * Metodo para generar los guiones 
 */
    public void vaciarletras() {

        GridLayout layout = new GridLayout(2, palabra.length(), 0, 1);
        PALABRAS.setLayout(layout);
        letras = new ArrayList<>();
        Respuesta8.setText("");

        for (int i = 0; i < palabra.length(); i++) {

            JLabel letra = new JLabel();

            letra.setText(String.valueOf(palabra.charAt(i)));

            letra.setVisible(false);
            letra.setForeground(Color.WHITE);
            letra.setFont(new Font("roboto", 1, 34));

            PALABRAS.add(letra);
            letras.add(letra);

        }
        for (int i = 0; i < palabra.length(); i++) {
            JLabel simbolo = new JLabel();

            simbolo.setText("___");
            simbolo.setForeground(Color.WHITE);
            simbolo.setFont(new Font("roboto", 1, 28));
            PALABRAS.add(simbolo);

        }

        indice = 0;
        intentospositivos = 0;
        intentosnegativos = 0;

    }
/**
 * 
 * @param a se recive un entero que servira para implementar el case  
 */
    public void imprimirmonito(int a) {
        ImageIcon img;

        switch (a) {
            case 0:
                img = new ImageIcon(getClass().getResource
                        ("/Media/Imagenes/ahorcado_0.png"));
                monito.setIcon(img);

                break;

            case 1:
                img = new ImageIcon(getClass().getResource
                            ("/Media/Imagenes/ahorcado_1.png"));
                monito.setIcon(img);

                break;
            case 2:
                img = new ImageIcon(getClass().getResource
                                    ("/Media/Imagenes/ahorcado_2.png"));
                monito.setIcon(img);

                break;
            case 3:
                img = new ImageIcon(getClass().getResource
                                      ("/Media/Imagenes/ahorcado_3.png"));
                monito.setIcon(img);

                break;
            case 4:
                img = new ImageIcon(getClass().getResource
                                    ("/Media/Imagenes/ahorcado_4.png"));
                monito.setIcon(img);

                break;
            case 5:
                img = new ImageIcon(getClass().getResource
                                    ("/Media/Imagenes/ahorcado_5.png"));
                monito.setIcon(img);
                break;
            case 6:
                img = new ImageIcon(getClass().getResource  
                            ("/Media/Imagenes/ahorcado_6.png"));
                monito.setIcon(img);
                break;
        }

    }
/**
 * Regresa a la forma visible a todad las ltras ya que no se sabe cuales fueron 
 * pulsadas 
 */
    private void reanudar() {
        a.setEnabled(true);
        b.setEnabled(true);
        c.setEnabled(true);
        d.setEnabled(true);
        e.setEnabled(true);
        f.setEnabled(true);
        g.setEnabled(true);
        h.setEnabled(true);
        i.setEnabled(true);
        j.setEnabled(true);
        k.setEnabled(true);
        l.setEnabled(true);
        m.setEnabled(true);
        n.setEnabled(true);
        ñ.setEnabled(true);
        o.setEnabled(true);
        p.setEnabled(true);
        q.setEnabled(true);
        r.setEnabled(true);
        s.setEnabled(true);
        t.setEnabled(true);
        u.setEnabled(true);
        v.setEnabled(true);
        w.setEnabled(true);
        x.setEnabled(true);
        Y.setEnabled(true);
        z.setEnabled(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ACIERTOS;
    private javax.swing.JButton Atras;
    private javax.swing.JTextField ERROR;
    private javax.swing.JLabel LACIERTOS;
    private javax.swing.JLabel LERROR;
    private javax.swing.JPanel PALABRAS;
    private javax.swing.JLabel Respuesta8;
    private javax.swing.JButton Y;
    private javax.swing.JButton a;
    private javax.swing.JButton b;
    private javax.swing.JButton c;
    private javax.swing.JButton d;
    private javax.swing.JButton e;
    private javax.swing.JButton f;
    private javax.swing.JLabel fondo;
    private javax.swing.JButton g;
    private javax.swing.JButton h;
    private javax.swing.JButton i;
    private javax.swing.JButton j;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton k;
    private javax.swing.JButton l;
    private javax.swing.JButton m;
    private javax.swing.JLabel monito;
    private javax.swing.JButton n;
    private javax.swing.JButton o;
    private javax.swing.JButton p;
    private javax.swing.JButton q;
    private javax.swing.JButton r;
    private javax.swing.JButton reset;
    private javax.swing.JButton s;
    private javax.swing.JButton silencio;
    private javax.swing.JButton t;
    private javax.swing.JButton u;
    private javax.swing.JButton v;
    private javax.swing.JButton w;
    private javax.swing.JButton x;
    private javax.swing.JButton z;
    private javax.swing.JButton ñ;
    // End of variables declaration//GEN-END:variables
}
