/** ************************************************************************
 *@author:Carlos Aurelio Alcántara Pérez
 * Fecha de creación: 07-04-2022 
 *@version Fecha de actualización:21-06-2022
 * @deprecated Ventana principal 
 * ************************************************************************* */
package ahorcado.juego.view;


import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;


public final class PrincipalGrafico extends javax.swing.JFrame  {
    
    BasicPlayer player = new BasicPlayer();//Creacion del player para el sonido
    Juego jugar;//Estancia de Juego para la apertura de su interfaz gráfica 
    Puntajes_altos PA = new Puntajes_altos(this);//Estancia de Puntajes_Altos 
    //para la apertura de su interfaz gráfica 

    /**
    * constructor para el inicio de todos los componentes
    */
    public PrincipalGrafico() {

        initComponents();
        this.setLocationRelativeTo(null);
        sonido();
 
    }
    /**
     * 
     * @param audio  este constructor es para no perder la secencia del sonido 
     * y poder pausarlo en todas las ventanas  
     */
    public PrincipalGrafico(BasicPlayer audio) {
        this.player = audio;
        initComponents();
        this.setLocationRelativeTo(null);
        
 
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PantallaPricipal = new javax.swing.JPanel();
        TITULO = new javax.swing.JLabel();
        JUGAR = new javax.swing.JButton();
        PUNTAJESALTOS = new javax.swing.JButton();
        SALIR = new javax.swing.JButton();
        Silenciar = new javax.swing.JButton();
        AYUDA = new javax.swing.JButton();
        FONDO = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(645, 528));

        PantallaPricipal.setBackground(new java.awt.Color(159, 197, 248));
        PantallaPricipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TITULO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/AHORCADO.png"))); // NOI18N
        PantallaPricipal.add(TITULO, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));

        JUGAR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/JUGARBOTON.png"))); // NOI18N
        JUGAR.setBorderPainted(false);
        JUGAR.setContentAreaFilled(false);
        JUGAR.setDefaultCapable(false);
        JUGAR.setFocusPainted(false);
        JUGAR.setFocusable(false);
        JUGAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JUGARActionPerformed(evt);
            }
        });
        PantallaPricipal.add(JUGAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, 127, -1));

        PUNTAJESALTOS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/PUNTAJESALTOSBOTON.png"))); // NOI18N
        PUNTAJESALTOS.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PUNTAJESALTOS.setBorderPainted(false);
        PUNTAJESALTOS.setContentAreaFilled(false);
        PUNTAJESALTOS.setFocusPainted(false);
        PUNTAJESALTOS.setFocusable(false);
        PUNTAJESALTOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PUNTAJESALTOSActionPerformed(evt);
            }
        });
        PantallaPricipal.add(PUNTAJESALTOS, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, -1, -1));

        SALIR.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/SALIRBOTON.png"))); // NOI18N
        SALIR.setBorderPainted(false);
        SALIR.setContentAreaFilled(false);
        SALIR.setFocusPainted(false);
        SALIR.setFocusable(false);
        SALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SALIRActionPerformed(evt);
            }
        });
        PantallaPricipal.add(SALIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, 140, -1));

        Silenciar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/Icon/SILENCIAR.png"))); // NOI18N
        Silenciar.setBorderPainted(false);
        Silenciar.setContentAreaFilled(false);
        Silenciar.setFocusPainted(false);
        Silenciar.setFocusable(false);
        Silenciar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SilenciarMouseClicked(evt);
            }
        });
        PantallaPricipal.add(Silenciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 450, -1, -1));

        AYUDA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/AYUDAINICIO.png"))); // NOI18N
        AYUDA.setBorderPainted(false);
        AYUDA.setContentAreaFilled(false);
        AYUDA.setFocusPainted(false);
        AYUDA.setFocusable(false);
        AYUDA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AYUDAActionPerformed(evt);
            }
        });
        PantallaPricipal.add(AYUDA, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 310, -1, -1));

        FONDO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Imagenes/FONDO.jpg"))); // NOI18N
        FONDO.setMinimumSize(new java.awt.Dimension(645, 510));
        FONDO.setPreferredSize(new java.awt.Dimension(645, 510));
        PantallaPricipal.add(FONDO, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 510));

        getContentPane().add(PantallaPricipal, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
        /**
         * 
         * @param evt apertura de la interfaz gráfica dej juego haciendo uso de 
         * la instancia @see juego
         *
         */
    private void JUGARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JUGARActionPerformed
        new Juego(player).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_JUGARActionPerformed
    /**
     * 
     * @param evt apertura de la intefaz gráfica de puntajes altos  
     */
    private void PUNTAJESALTOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PUNTAJESALTOSActionPerformed
       

        PA.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_PUNTAJESALTOSActionPerformed
/**
 * 
 * @param evt salida del programa 
 */
    private void SALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SALIRActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SALIRActionPerformed
/**
 * 
 * @param evt pausa todos los sonidos 
 * @see  mute es donde se implementa los try y cath
 */
    private void SilenciarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SilenciarMouseClicked
        mute();
    }//GEN-LAST:event_SilenciarMouseClicked
/**
 * 
 * @param evt muestra una ventana de ayuda 
 */
    private void AYUDAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AYUDAActionPerformed
      JOptionPane.showMessageDialog(null, "Estamos trabajando en esto");
    }//GEN-LAST:event_AYUDAActionPerformed

    /**
     * @param args main del archivo 
     */
    public static void main(String args[]) {
       
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrincipalGrafico().setVisible(true);
            }
        });
    }
/**
 * método para abrir y reproducir el sonido 
 */
    public void sonido() {
        try {
          player.open(new File("/Media/Audio/tetrisgameboy1-gameboy.mp3"));
            player.play();
        } catch (Exception e) {
        }
    }
    
    
/**
 * mute método para pausar el sonido 
 */
    public void mute() {
        if (player.getStatus() == BasicPlayer.PAUSED) {
            
            try {
                player.resume();
            } catch (BasicPlayerException ex) {
                Logger.getLogger(PrincipalGrafico.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }else if (player.getStatus() == BasicPlayer.PLAYING){
            try {
            player.pause();
        } catch (BasicPlayerException e) {
        }
            
        }
        

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AYUDA;
    private javax.swing.JLabel FONDO;
    private javax.swing.JButton JUGAR;
    private javax.swing.JButton PUNTAJESALTOS;
    private javax.swing.JPanel PantallaPricipal;
    private javax.swing.JButton SALIR;
    private javax.swing.JButton Silenciar;
    private javax.swing.JLabel TITULO;
    // End of variables declaration//GEN-END:variables

   

}
